package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText getInput1;
    EditText getInput2;
    Button button;

    Button button2;

    Button button3;

    TextView textView;

    int Sum;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        getInput1 = findViewById(R.id.editTextNumber);
        getInput2 = findViewById(R.id.editTextNumber2);

        textView = findViewById(R.id.textView);

        button = findViewById(R.id.button);
        button2 = findViewById(R.id.button5);
        button3 = findViewById(R.id.button6);
        //Sumaaa
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                    int Sum = Integer.parseInt(getInput1.getText().toString()) + Integer.parseInt(getInput2.getText().toString());

                    textView.setText(Integer.toString(Sum));

            }
        });

        //Multiplicacion
        button2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int Sum = Integer.parseInt(getInput1.getText().toString()) * Integer.parseInt(getInput2.getText().toString());

                textView.setText(Integer.toString(Sum));

            }
        });
        //Division
        button3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int Sum = Integer.parseInt(getInput1.getText().toString()) / Integer.parseInt(getInput2.getText().toString());

                textView.setText(Integer.toString(Sum));

            }
        });


    }
}