import android.os.Bundle;

public abstract class AppCompatActivity {
    protected abstract void onCreate(Bundle savedInstanceState);
}
