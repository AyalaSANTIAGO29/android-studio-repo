package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private TextView textViewAccelerometer;
    private boolean isAccelerometerEnabled = false;

    private Sensor proximitySensor;

    private TextView textViewProximity;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Habilitar el ActionBar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        // Inicializar el SensorManager y el acelerómetro
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);

        if (proximitySensor == null) {
            // El dispositivo no tiene sensor de proximidad
            textViewProximity.setText("No se encontró el sensor de proximidad en este dispositivo");
        }
        // Enlazar el TextView
        textViewAccelerometer = findViewById(R.id.textAccelerometer);
        textViewProximity = findViewById(R.id.textProximity);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.action_toggle_accelerometer) {
            // Alternar el estado del acelerómetro
            isAccelerometerEnabled = !isAccelerometerEnabled;

            if (isAccelerometerEnabled) {
                // Registrar el SensorEventListener si se activa el acelerómetro
                sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
                Toast.makeText(this, "Acelerómetro activado", Toast.LENGTH_SHORT).show();
            } else {
                // Detener la actualización del acelerómetro si se desactiva
                sensorManager.unregisterListener(this);
                Toast.makeText(this, "Acelerómetro desactivado", Toast.LENGTH_SHORT).show();
            }

            return true;
        } else if (itemId == android.R.id.home) {
            // Manejar el evento de clic en el ícono de inicio del ActionBar
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Registrar el SensorEventListener para el acelerómetro si está habilitado
        if (isAccelerometerEnabled) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Detener la actualización del acelerómetro al pausar la actividad
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        // Obtener los valores del acelerómetro
        float xAxis = event.values[0];
        float yAxis = event.values[1];
        float zAxis = event.values[2];

        // Convertir a enteros
        int xValue = (int) xAxis;
        int yValue = (int) yAxis;
        int zValue = (int) zAxis;

        // Actualizar el texto en el TextView
        textViewAccelerometer.setText("Acelerómetro\n\nX: " + xValue + "\nY: " + yValue + "\nZ: " + zValue);

        // Obtener el valor del sensor de proximidad y convertirlo a entero
        int proximityValue = (int) event.values[0];

        // Actualizar el texto en el TextView
        textViewProximity.setText("Proximidad: " + proximityValue);

    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // No se
    }
}